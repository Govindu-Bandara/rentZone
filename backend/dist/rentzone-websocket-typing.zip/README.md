# rentzone-websocket-typing

Lambda function for RentZone platform.

## Description
This function handles: [Add description based on function name]

## Environment Variables
- `MONGODB_URI_PARAM`: MongoDB connection string parameter
- `JWT_SECRET`: JWT secret for authentication
- `AWS_REGION`: AWS region (ap-south-1)

## Last Updated
2025-12-23 21:55:03
